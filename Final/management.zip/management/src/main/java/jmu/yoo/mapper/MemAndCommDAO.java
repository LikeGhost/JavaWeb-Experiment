package jmu.yoo.mapper;

import jmu.yoo.vo.MemAndComm;

import java.util.List;

public interface MemAndCommDAO {

    List<MemAndComm> selectMemAndCommIsOutCity();
}
