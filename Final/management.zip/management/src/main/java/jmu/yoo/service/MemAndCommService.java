package jmu.yoo.service;

import jmu.yoo.vo.MemAndComm;

import java.util.List;

public interface MemAndCommService {
    List<MemAndComm> findMemAndCommIsOutCity();
}
